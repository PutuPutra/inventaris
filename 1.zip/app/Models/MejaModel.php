<?php

namespace App\Models;

use CodeIgniter\Model;

class MejaModel extends Model
{

    protected $table            = 'meja';
    protected $primaryKey       = 'id';
    protected $returnType       = 'object';
    protected $allowedFields = ['serial_number','ukuran_meja', 'gambar_meja', 'kondisi_meja','id_kelas'];
}
