<?= $this->extend('/layout/templateAdmin'); ?>
<?= $this->section('admin'); ?>

<?= $this->endSection(); ?>




<div class="class=" page-header-fixed page-sidebar-fixed pace-done page-footer-fixed theme-shadow""></div>
