jQuery(document).ready(function () {
	
    $('#pwstrength-example').pwstrength({
      ui: {
        progressExtraCssClasses: 'pwstrength-progress',
        useVerdictCssClass: true,
        showErrors: true,
		showScore: true
		
      }
    });	

});
