$(function () {
	'use strict';

	// Dual Listbox Example 
   $('#duallistbox-example').bootstrapDualListbox({
	 nonSelectedListLabel: 'Non-selected',
	 selectedListLabel: 'Selected',
	 preserveSelectionOnMove: 'moved',
	 moveOnSelect: false
   });
   
})